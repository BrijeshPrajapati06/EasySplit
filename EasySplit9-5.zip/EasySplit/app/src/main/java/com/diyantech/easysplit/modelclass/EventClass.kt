package com.diyantech.easysplit.modelclass

data class EventClass(
    var txt_ladakh : String,
    var txt_description : String,
    var txt_created : String,
    var txt_price : String
) {
}