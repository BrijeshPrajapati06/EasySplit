package com.diyantech.easysplit.modelclass

data class DialogPurchaseClass(
    var user: String,
    var rbuser: Boolean
) {
}