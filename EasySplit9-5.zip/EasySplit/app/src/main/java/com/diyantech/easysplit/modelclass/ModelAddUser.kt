package com.diyantech.easysplit.modelclass

data class ModelAddUser(
    var name: String,
    var userImage : Int
) {
}