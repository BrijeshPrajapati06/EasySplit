package com.diyantech.easysplit.modelclass

class ErrorResponseModel (
    val code: String,
    val messages: List<String>,
    val status: String
)
