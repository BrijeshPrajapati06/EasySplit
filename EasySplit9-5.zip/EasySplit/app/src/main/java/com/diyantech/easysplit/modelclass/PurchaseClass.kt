package com.diyantech.easysplit.modelclass

data class PurchaseClass(
    var hotelRoom : String,
    var paidUser : String,
    var payEveryone : String,
    var Price : String,
    var igNum : Int,
) {
}