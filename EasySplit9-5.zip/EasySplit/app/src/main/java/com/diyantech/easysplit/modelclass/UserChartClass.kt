package com.diyantech.easysplit.modelclass

import android.widget.ImageView

data class UserChartClass(
    var imgProfile : Int,
    var name: String,
    var txSpend : String,
    var price : String
) {
}