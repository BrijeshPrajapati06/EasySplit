package com.diyantech.easysplit.modelclass

data class SplitClass(
    var igProfile: Int,
    var igProfile2: Int,
    var name: String,
    var rightarrow: Int,
    var price: String,
    var rightarrow2: Int,
    var name2: String
) {
}